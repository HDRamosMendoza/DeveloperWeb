let x: number = 5
console.log(`El valor de x es: ${x}`);

// x = "fff";

function retornaNumero(x: number): number{
    return x;
}

function retornarCualquierCosa(): any{
    
}