import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Table } from "./components/Table";

interface IProducto {
  nombre: string;
  precio: number;
}

interface ICliente {
  nombre: string;
  apellido: string;
  edad: number;
}

const App: React.FC = () => {
  // const array = [1,2,3,4,5,6,7];
  // const array1 = new Array(100);
  // const arrayTables = [];  
  // for (let index = 0; index < 1; index++) {
  //   arrayTables.push(<Table title={`Tabla ${index}`} key={index} data={dataPruebaProducto}></Table>)
  // }
  // const tableViews = array.map((index)=>{
  //   return <Table title={`Tabla ${index}`}></Table>
  // })

  // creando data de prueba
  const dataPruebaProducto: IProducto[] = [{ nombre: "P1", precio: 100 }];
  const dataPruebaClientes: ICliente[] = [
    { nombre: "P1", apellido: "apellido", edad: 12 },
    { nombre: "P1", apellido: "apellido", edad: 12 },
    { nombre: "P1", apellido: "apellido", edad: 12 }];
    
  return (
    <>
      <Table title="Tabla Productos" data={dataPruebaProducto}></Table>
      <Table title="Tabla Clientes" data={dataPruebaClientes}></Table>
    </>
  );
}

export default App;
