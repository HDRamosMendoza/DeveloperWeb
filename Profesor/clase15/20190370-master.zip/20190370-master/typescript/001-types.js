var x = 5;
console.log("El valor de x es: " + x);
// x = "fff";
function retornaNumero(x) {
    return x;
}
function retornarCualquierCosa() {
}
